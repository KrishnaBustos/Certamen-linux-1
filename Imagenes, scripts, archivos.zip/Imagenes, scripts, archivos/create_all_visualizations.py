#!/usr/bin/env python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

print("Creando visualizaciones...")

# Configurar estilo
sns.set_style("whitegrid")
plt.rcParams['font.size'] = 10

# Leer datos
metrics = pd.read_csv('model_metrics.csv')

print("1. Comparación de Test Accuracy...")
# 1. Comparación de Test Accuracy
plt.figure(figsize=(12, 6))
colors = ['#2ecc71' if x == metrics['test_accuracy'].max() else '#3498db' 
          for x in metrics['test_accuracy']]
bars = plt.bar(range(len(metrics)), metrics['test_accuracy'], color=colors, 
               edgecolor='black', linewidth=1.5)
plt.xticks(range(len(metrics)), metrics['learner_name'], rotation=45, ha='right')
plt.ylabel('Test Accuracy', fontweight='bold', fontsize=12)
plt.title('Comparación de Test Accuracy entre Modelos', fontweight='bold', fontsize=14)
plt.ylim([0, 1.05])
plt.axhline(y=metrics['test_accuracy'].max(), color='red', linestyle='--', 
            alpha=0.5, label='Mejor modelo')
plt.legend()
for i, (bar, val) in enumerate(zip(bars, metrics['test_accuracy'])):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, 
             f'{val:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold')
plt.tight_layout()
plt.savefig('model_test_accuracy.png', dpi=300, bbox_inches='tight')
plt.close()
print("   ✓ model_test_accuracy.png")

print("2. Train vs Test Accuracy...")
# 2. Train vs Test Accuracy
plt.figure(figsize=(12, 6))
x = np.arange(len(metrics))
width = 0.35
plt.bar(x - width/2, metrics['train_accuracy'], width, label='Train', 
        color='#e74c3c', alpha=0.8, edgecolor='black')
plt.bar(x + width/2, metrics['test_accuracy'], width, label='Test', 
        color='#3498db', alpha=0.8, edgecolor='black')
plt.xticks(x, metrics['learner_name'], rotation=45, ha='right')
plt.ylabel('Accuracy', fontweight='bold', fontsize=12)
plt.title('Train vs Test Accuracy', fontweight='bold', fontsize=14)
plt.legend(fontsize=11)
plt.ylim([0, 1.1])
plt.tight_layout()
plt.savefig('train_vs_test_accuracy.png', dpi=300, bbox_inches='tight')
plt.close()
print("   ✓ train_vs_test_accuracy.png")

print("3. Todas las métricas...")
# 3. Todas las métricas
plt.figure(figsize=(14, 6))
metrics_long = metrics[['learner_name', 'test_accuracy', 'precision', 'recall', 'f1']].melt(
    id_vars='learner_name',
    value_vars=['test_accuracy', 'precision', 'recall', 'f1'],
    var_name='metric',
    value_name='value'
)
# Renombrar para mejor visualización
metrics_long['metric'] = metrics_long['metric'].replace({
    'test_accuracy': 'Accuracy',
    'precision': 'Precision',
    'recall': 'Recall',
    'f1': 'F1-Score'
})
sns.barplot(data=metrics_long, x='learner_name', y='value', hue='metric', 
            palette=['#3498db', '#e74c3c', '#2ecc71', '#f39c12'])
plt.xticks(rotation=45, ha='right')
plt.xlabel('Modelo', fontweight='bold', fontsize=12)
plt.ylabel('Valor de la Métrica', fontweight='bold', fontsize=12)
plt.title('Comparación de Todas las Métricas en Test', fontweight='bold', fontsize=14)
plt.legend(title='Métrica', fontsize=10)
plt.ylim([0, 1.1])
plt.tight_layout()
plt.savefig('all_metrics_comparison.png', dpi=300, bbox_inches='tight')
plt.close()
print("   ✓ all_metrics_comparison.png")

print("4. F1-Score vs Accuracy...")
# 4. F1-Score vs Accuracy
plt.figure(figsize=(10, 8))
for idx, row in metrics.iterrows():
    color = '#2ecc71' if row['test_accuracy'] == metrics['test_accuracy'].max() else '#3498db'
    size = 300 if row['test_accuracy'] == metrics['test_accuracy'].max() else 200
    plt.scatter(row['test_accuracy'], row['f1'], s=size, alpha=0.7, 
                color=color, edgecolor='black', linewidth=2)
    plt.annotate(row['learner_name'], 
                (row['test_accuracy'], row['f1']),
                xytext=(5, 5), textcoords='offset points', 
                fontsize=9, fontweight='bold')
plt.xlabel('Test Accuracy', fontweight='bold', fontsize=12)
plt.ylabel('F1-Score', fontweight='bold', fontsize=12)
plt.title('F1-Score vs Test Accuracy', fontweight='bold', fontsize=14)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('f1_vs_accuracy.png', dpi=300, bbox_inches='tight')
plt.close()
print("   ✓ f1_vs_accuracy.png")

print("5. Overfitting...")
# 5. Overfitting
plt.figure(figsize=(12, 6))
overfitting = metrics['train_accuracy'] - metrics['test_accuracy']
colors_over = ['#e74c3c' if x > 0.1 else '#f39c12' if x > 0.05 else '#2ecc71' 
               for x in overfitting]
bars = plt.bar(range(len(metrics)), overfitting, color=colors_over, 
               edgecolor='black', linewidth=1.5)
plt.xticks(range(len(metrics)), metrics['learner_name'], rotation=45, ha='right')
plt.ylabel('Train Accuracy - Test Accuracy', fontweight='bold', fontsize=12)
plt.title('Detección de Overfitting', fontweight='bold', fontsize=14)
plt.axhline(y=0.05, color='orange', linestyle='--', alpha=0.5, 
            label='Overfitting leve (0.05)')
plt.axhline(y=0.1, color='red', linestyle='--', alpha=0.5, 
            label='Overfitting alto (0.10)')
plt.legend(fontsize=10)
for bar, val in zip(bars, overfitting):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.003, 
             f'{val:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold')
plt.tight_layout()
plt.savefig('overfitting_comparison.png', dpi=300, bbox_inches='tight')
plt.close()
print("   ✓ overfitting_comparison.png")

print("6. Visualización completa (6 paneles)...")
# Crear figura con 6 subplots
fig, axes = plt.subplots(3, 2, figsize=(16, 14))
fig.suptitle('Análisis Comparativo de Modelos de Clasificación - Terremotos', 
             fontsize=16, fontweight='bold', y=0.995)

# 6.1. Comparación de Test Accuracy
ax1 = axes[0, 0]
colors = ['#2ecc71' if x == metrics['test_accuracy'].max() else '#3498db' 
          for x in metrics['test_accuracy']]
bars1 = ax1.bar(range(len(metrics)), metrics['test_accuracy'], color=colors, 
                edgecolor='black', linewidth=1.5)
ax1.set_xticks(range(len(metrics)))
ax1.set_xticklabels(metrics['learner_name'], rotation=45, ha='right')
ax1.set_ylabel('Test Accuracy', fontweight='bold')
ax1.set_title('1. Comparación de Test Accuracy', fontweight='bold', pad=10)
ax1.set_ylim([0, 1.05])
for i, (bar, val) in enumerate(zip(bars1, metrics['test_accuracy'])):
    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, 
             f'{val:.3f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

# 6.2. Train vs Test
ax2 = axes[0, 1]
x = np.arange(len(metrics))
width = 0.35
ax2.bar(x - width/2, metrics['train_accuracy'], width, label='Train', 
        color='#e74c3c', alpha=0.8, edgecolor='black')
ax2.bar(x + width/2, metrics['test_accuracy'], width, label='Test', 
        color='#3498db', alpha=0.8, edgecolor='black')
ax2.set_xticks(x)
ax2.set_xticklabels(metrics['learner_name'], rotation=45, ha='right')
ax2.set_ylabel('Accuracy', fontweight='bold')
ax2.set_title('2. Train vs Test Accuracy', fontweight='bold', pad=10)
ax2.legend()
ax2.set_ylim([0, 1.1])

# 6.3. Todas las métricas
ax3 = axes[1, 0]
x_pos = np.arange(len(metrics))
bar_width = 0.18
colors_metrics = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12']
labels_metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
cols = ['test_accuracy', 'precision', 'recall', 'f1']

for i, (col, color, label) in enumerate(zip(cols, colors_metrics, labels_metrics)):
    offset = (i - 1.5) * bar_width
    ax3.bar(x_pos + offset, metrics[col], bar_width, label=label, 
            color=color, alpha=0.8, edgecolor='black')

ax3.set_xticks(x_pos)
ax3.set_xticklabels(metrics['learner_name'], rotation=45, ha='right')
ax3.set_ylabel('Valor', fontweight='bold')
ax3.set_title('3. Comparación de Todas las Métricas', fontweight='bold', pad=10)
ax3.legend(loc='lower left')
ax3.set_ylim([0, 1.1])

# 6.4. Overfitting
ax4 = axes[1, 1]
overfitting = metrics['train_accuracy'] - metrics['test_accuracy']
colors_over = ['#e74c3c' if x > 0.1 else '#f39c12' if x > 0.05 else '#2ecc71' 
               for x in overfitting]
bars4 = ax4.bar(range(len(metrics)), overfitting, color=colors_over, 
                edgecolor='black', linewidth=1.5)
ax4.set_xticks(range(len(metrics)))
ax4.set_xticklabels(metrics['learner_name'], rotation=45, ha='right')
ax4.set_ylabel('Train - Test Accuracy', fontweight='bold')
ax4.set_title('4. Detección de Overfitting', fontweight='bold', pad=10)
ax4.axhline(y=0.05, color='orange', linestyle='--', alpha=0.5)
ax4.axhline(y=0.1, color='red', linestyle='--', alpha=0.5)

# 6.5. F1 vs Accuracy
ax5 = axes[2, 0]
for idx, row in metrics.iterrows():
    color = '#2ecc71' if row['test_accuracy'] == metrics['test_accuracy'].max() else '#3498db'
    size = 300 if row['test_accuracy'] == metrics['test_accuracy'].max() else 200
    ax5.scatter(row['test_accuracy'], row['f1'], s=size, alpha=0.7, 
                color=color, edgecolor='black', linewidth=2)
    ax5.annotate(row['learner_name'], 
                (row['test_accuracy'], row['f1']),
                xytext=(5, 5), textcoords='offset points', 
                fontsize=8, fontweight='bold')
ax5.set_xlabel('Test Accuracy', fontweight='bold')
ax5.set_ylabel('F1-Score', fontweight='bold')
ax5.set_title('5. F1-Score vs Test Accuracy', fontweight='bold', pad=10)
ax5.grid(True, alpha=0.3)

# 6.6. Ranking
ax6 = axes[2, 1]
metrics_sorted = metrics.sort_values('test_accuracy', ascending=True)
colors_rank = ['#2ecc71' if x == metrics_sorted['test_accuracy'].max() else '#3498db' 
               for x in metrics_sorted['test_accuracy']]
bars6 = ax6.barh(range(len(metrics_sorted)), metrics_sorted['test_accuracy'], 
                 color=colors_rank, edgecolor='black', linewidth=1.5)
ax6.set_yticks(range(len(metrics_sorted)))
ax6.set_yticklabels(metrics_sorted['learner_name'])
ax6.set_xlabel('Test Accuracy', fontweight='bold')
ax6.set_title('6. Ranking de Modelos', fontweight='bold', pad=10)
ax6.set_xlim([0, 1.05])
for i, (bar, val) in enumerate(zip(bars6, metrics_sorted['test_accuracy'])):
    ax6.text(val + 0.01, bar.get_y() + bar.get_height()/2, 
             f'{val:.4f}', va='center', fontsize=9, fontweight='bold')

plt.tight_layout()
plt.savefig('complete_model_analysis.png', dpi=300, bbox_inches='tight')
plt.close()
print("   ✓ complete_model_analysis.png")

print("7. Tabla de métricas...")
# Crear tabla resumen
fig2, ax = plt.subplots(figsize=(14, 6))
ax.axis('tight')
ax.axis('off')

table_data = []
table_data.append(['Modelo', 'Train Acc', 'Test Acc', 'Precision', 'Recall', 'F1-Score', 'Overfitting'])
for _, row in metrics.sort_values('test_accuracy', ascending=False).iterrows():
    overfit = row['train_accuracy'] - row['test_accuracy']
    table_data.append([
        row['learner_name'],
        f"{row['train_accuracy']:.4f}",
        f"{row['test_accuracy']:.4f}",
        f"{row['precision']:.4f}",
        f"{row['recall']:.4f}",
        f"{row['f1']:.4f}",
        f"{overfit:.4f}"
    ])

table = ax.table(cellText=table_data, cellLoc='center', loc='center',
                colWidths=[0.3, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12])
table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1, 2.5)

for i in range(7):
    cell = table[(0, i)]
    cell.set_facecolor('#3498db')
    cell.set_text_props(weight='bold', color='white')

for i in range(7):
    cell = table[(1, i)]
    cell.set_facecolor('#2ecc71')
    cell.set_text_props(weight='bold')

plt.title('Tabla Resumen de Métricas de Evaluación', 
          fontsize=14, fontweight='bold', pad=20)
plt.savefig('metrics_table.png', dpi=300, bbox_inches='tight')
plt.close()
print("   ✓ metrics_table.png")

print("\n" + "="*60)
print("¡TODAS LAS VISUALIZACIONES COMPLETADAS!")
print("="*60)
