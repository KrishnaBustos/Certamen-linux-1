#!/usr/bin/env python3
import csv

with open('earthquakes_clean2.csv', 'r') as infile, \
     open('earthquakes_with_year.csv', 'w', newline='') as outfile:
    
    reader = csv.reader(infile)
    writer = csv.writer(outfile)
    
    # Leer y escribir header
    header = next(reader)
    writer.writerow(header + ['year'])
    
    # Procesar cada fila
    for row in reader:
        time_str = row[0]  # primera columna es 'time'
        year = time_str.split('-')[0]  # extraer año (YYYY)
        writer.writerow(row + [year])

print("Archivo creado exitosamente!")
