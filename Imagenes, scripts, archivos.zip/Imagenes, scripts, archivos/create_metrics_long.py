import pandas as pd

# Leer métricas
df = pd.read_csv('model_metrics.csv')

# Seleccionar columnas y transformar a formato largo
metrics_long = df[['learner_name', 'test_accuracy', 'precision', 'recall', 'f1']].melt(
    id_vars='learner_name',
    value_vars=['test_accuracy', 'precision', 'recall', 'f1'],
    var_name='metric',
    value_name='value'
)

# Guardar
metrics_long.to_csv('all_metrics_long.csv', index=False)
print("✓ all_metrics_long.csv creado")
print(metrics_long.head(10))
